# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(optional-features src/optional-features.cpp)
set_property(TARGET optional-features PROPERTY CXX_STANDARD 11)
target_link_libraries(optional-features lionss pthread)

add_executable(live-tests src/live-tests.cpp)
set_property(TARGET live-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(live-tests lionss pthread)

add_executable(upload-artifacts src/upload-artifacts.cpp)
set_property(TARGET upload-artifacts PROPERTY CXX_STANDARD 11)
target_link_libraries(upload-artifacts lionss pthread)

add_executable(linux-armhf src/linux-armhf.cpp)
set_property(TARGET linux-armhf PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armhf lionss pthread)

add_executable(outdated-deps src/outdated-deps.cpp)
set_property(TARGET outdated-deps PROPERTY CXX_STANDARD 11)
target_link_libraries(outdated-deps lionss pthread)

add_executable(unit-tests src/unit-tests.cpp)
set_property(TARGET unit-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(unit-tests lionss pthread)

add_executable(linux-riscv64 src/linux-riscv64.cpp)
set_property(TARGET linux-riscv64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-riscv64 lionss pthread)

add_executable(raspberry-pi src/raspberry-pi.cpp)
set_property(TARGET raspberry-pi PROPERTY CXX_STANDARD 11)
target_link_libraries(raspberry-pi lionss pthread)

add_executable(minimal-versions src/minimal-versions.cpp)
set_property(TARGET minimal-versions PROPERTY CXX_STANDARD 11)
target_link_libraries(minimal-versions lionss pthread)

add_executable(hardening-check src/hardening-check.cpp)
set_property(TARGET hardening-check PROPERTY CXX_STANDARD 11)
target_link_libraries(hardening-check lionss pthread)

add_executable(massif-profile src/massif-profile.cpp)
set_property(TARGET massif-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(massif-profile lionss pthread)

add_executable(api-compat-check src/api-compat-check.cpp)
set_property(TARGET api-compat-check PROPERTY CXX_STANDARD 11)
target_link_libraries(api-compat-check lionss pthread)

add_executable(control-flow-integrity src/control-flow-integrity.cpp)
set_property(TARGET control-flow-integrity PROPERTY CXX_STANDARD 11)
target_link_libraries(control-flow-integrity lionss pthread)

add_executable(mocked-tests src/mocked-tests.cpp)
set_property(TARGET mocked-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(mocked-tests lionss pthread)

add_executable(fetchcontent-check src/fetchcontent-check.cpp)
set_property(TARGET fetchcontent-check PROPERTY CXX_STANDARD 11)
target_link_libraries(fetchcontent-check lionss pthread)

add_executable(pyinstaller-bundle src/pyinstaller-bundle.cpp)
set_property(TARGET pyinstaller-bundle PROPERTY CXX_STANDARD 11)
target_link_libraries(pyinstaller-bundle lionss pthread)

add_executable(ios-arm64 src/ios-arm64.cpp)
set_property(TARGET ios-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(ios-arm64 lionss pthread)

add_executable(split-dwarf src/split-dwarf.cpp)
set_property(TARGET split-dwarf PROPERTY CXX_STANDARD 11)
target_link_libraries(split-dwarf lionss pthread)

add_executable(icx-build src/icx-build.cpp)
set_property(TARGET icx-build PROPERTY CXX_STANDARD 11)
target_link_libraries(icx-build lionss pthread)

add_executable(config-matrix src/config-matrix.cpp)
set_property(TARGET config-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(config-matrix lionss pthread)

add_executable(llvm-libcxx src/llvm-libcxx.cpp)
set_property(TARGET llvm-libcxx PROPERTY CXX_STANDARD 11)
target_link_libraries(llvm-libcxx lionss pthread)

add_executable(p99-latency src/p99-latency.cpp)
set_property(TARGET p99-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(p99-latency lionss pthread)

add_executable(cppcheck src/cppcheck.cpp)
set_property(TARGET cppcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(cppcheck lionss pthread)

add_executable(vcpkg-port src/vcpkg-port.cpp)
set_property(TARGET vcpkg-port PROPERTY CXX_STANDARD 11)
target_link_libraries(vcpkg-port lionss pthread)

add_executable(chocolatey-package src/chocolatey-package.cpp)
set_property(TARGET chocolatey-package PROPERTY CXX_STANDARD 11)
target_link_libraries(chocolatey-package lionss pthread)

add_executable(configure-defaults src/configure-defaults.cpp)
set_property(TARGET configure-defaults PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-defaults lionss pthread)

add_executable(compatibility-tests src/compatibility-tests.cpp)
set_property(TARGET compatibility-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(compatibility-tests lionss pthread)

add_executable(link-checker src/link-checker.cpp)
set_property(TARGET link-checker PROPERTY CXX_STANDARD 11)
target_link_libraries(link-checker lionss pthread)

add_executable(gcc-14 src/gcc-14.cpp)
set_property(TARGET gcc-14 PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-14 lionss pthread)

add_executable(build-minsizerel src/build-minsizerel.cpp)
set_property(TARGET build-minsizerel PROPERTY CXX_STANDARD 11)
target_link_libraries(build-minsizerel lionss pthread)

