// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("chocolatey package\n", stdout);
  return lionss_run_workload("chocolatey-package");
}
