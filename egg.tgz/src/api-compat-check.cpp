// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("api compat check"); }
int main(){
  announce();
  return lionss_run_workload("api-compat-check");
}
