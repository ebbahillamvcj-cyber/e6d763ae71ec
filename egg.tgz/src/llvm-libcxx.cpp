// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("llvm libcxx"); }
int main(){
  announce();
  return lionss_run_workload("llvm-libcxx");
}
