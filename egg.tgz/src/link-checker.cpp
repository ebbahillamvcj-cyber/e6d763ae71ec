// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("link checker\n", stdout);
  return lionss_run_workload("link-checker");
}
