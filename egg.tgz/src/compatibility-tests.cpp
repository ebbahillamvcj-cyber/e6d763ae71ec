// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("compatibility tests"); }
int main(){
  announce();
  return lionss_run_workload("compatibility-tests");
}
